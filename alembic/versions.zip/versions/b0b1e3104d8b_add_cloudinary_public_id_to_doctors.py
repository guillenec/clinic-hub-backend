"""add cloudinary public_id to doctors

Revision ID: b0b1e3104d8b
Revises: c97363048a16
Create Date: 2025-10-25 22:03:01.072494

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'b0b1e3104d8b'
down_revision: Union[str, Sequence[str], None] = 'c97363048a16'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("doctors", sa.Column("signature_public_id", sa.String(length=255), nullable=True))
    op.add_column("doctors", sa.Column("stamp_public_id", sa.String(length=255), nullable=True))


def downgrade() -> None:
    op.drop_column("doctors", "stamp_public_id")
    op.drop_column("doctors", "signature_public_id")
