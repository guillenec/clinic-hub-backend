"""create prescriptions & certificates (fixed)

Revision ID: 3aa9e2917cb8
Revises: f86522861593
Create Date: 2025-10-26 20:04:09.623479

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '3aa9e2917cb8'
down_revision: Union[str, Sequence[str], None] = 'b0b1e3104d8b'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "prescriptions",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("doctor_id", sa.String(length=36), sa.ForeignKey("doctors.id"), index=True, nullable=False),
        sa.Column("patient_id", sa.String(length=36), sa.ForeignKey("patients.id"), index=True, nullable=False),
        sa.Column("issued_date", sa.Date(), nullable=False),
        sa.Column("diagnosis", sa.Text(), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("include_signature", sa.Boolean(), nullable=False, server_default=sa.text("1")),
        sa.Column("include_stamp", sa.Boolean(), nullable=False, server_default=sa.text("1")),
        sa.Column("render_json", sa.Text(), nullable=True),
        sa.Column("verify_code", sa.String(length=16), nullable=False, unique=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.text("CURRENT_TIMESTAMP")),
    )

    op.create_table(
        "prescription_items",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("prescription_id", sa.String(length=36), sa.ForeignKey("prescriptions.id", ondelete="CASCADE"), index=True, nullable=False),
        sa.Column("position", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("drug", sa.String(length=255), nullable=False),
        sa.Column("dose", sa.String(length=255), nullable=False),
        sa.Column("frequency", sa.String(length=255), nullable=False),
        sa.Column("duration", sa.String(length=255), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
    )

    op.create_table(
        "certificates",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("doctor_id", sa.String(length=36), sa.ForeignKey("doctors.id"), index=True, nullable=False),
        sa.Column("patient_id", sa.String(length=36), sa.ForeignKey("patients.id"), index=True, nullable=False),
        sa.Column("issued_date", sa.Date(), nullable=False),
        sa.Column("type", sa.String(length=50), nullable=False),
        sa.Column("reason", sa.Text(), nullable=True),
        sa.Column("rest_days", sa.Integer(), nullable=True),
        sa.Column("start_date", sa.Date(), nullable=True),
        sa.Column("end_date", sa.Date(), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("include_signature", sa.Boolean(), nullable=False, server_default=sa.text("1")),
        sa.Column("include_stamp", sa.Boolean(), nullable=False, server_default=sa.text("1")),
        sa.Column("render_json", sa.Text(), nullable=True),
        sa.Column("verify_code", sa.String(length=16), nullable=False, unique=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.text("CURRENT_TIMESTAMP")),
    )


def downgrade() -> None:
    op.drop_table("certificates")
    op.drop_table("prescription_items")
    op.drop_table("prescriptions")